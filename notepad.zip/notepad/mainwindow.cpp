#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    this->setCentralWidget(ui->textEdit);
    this->setWindowTitle("~ notepad ~");
    ui->textEdit->setTextColor(QColor("#8CC1DB"));
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_actionnew_triggered()
{
//    note.clear();
    ui->textEdit->setText(QString());
}


void MainWindow::on_actionopen_triggered()
{
    QString note = QFileDialog::getOpenFileName(this, "open");
    if (note.isEmpty())
        return;

    QFile file(note);
    if (!file.open(QIODevice::Text | QIODevice::ReadOnly))
        return;

    QTextStream in(&file);
    QString notes = in.readAll();
    ui->textEdit->setText(notes);
    file.close();
}


void MainWindow::on_actionclose_triggered()
{
    QApplication::quit();
}


void MainWindow::on_actionsave_triggered()
{
    QString note = QFileDialog::getSaveFileName(this, "save");
    if (note.isEmpty())
        return;

    QFile file(note);
    if (!file.open(QIODevice::Text | QIODevice::WriteOnly))
        return;

    QTextStream out(&file);
    out << ui->textEdit->toPlainText();
    file.close();
}


void MainWindow::on_actionundo_triggered()
{
    ui->textEdit->undo();
}


void MainWindow::on_actionredo_triggered()
{
    ui->textEdit->redo();
}


void MainWindow::on_actioncut_triggered()
{
    ui->textEdit->cut();
}


void MainWindow::on_actioncopy_triggered()
{
    ui->textEdit->copy();
}


void MainWindow::on_actionpaste_triggered()
{
    ui->textEdit->paste();
}

